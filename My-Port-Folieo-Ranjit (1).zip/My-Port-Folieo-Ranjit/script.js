// Create the button element
const backToTopButton = document.createElement('button');
backToTopButton.innerText = '↑ Top';
backToTopButton.id = 'backToTop';
document.body.appendChild(backToTopButton);

// Style the button
const style = document.createElement('style');
style.innerHTML = `
    #backToTop {
        position: fixed;
        bottom: 30px;
        right: 30px;
        background: #222;
        color: white;
        border: none;
        padding: 10px 15px;
        font-size: 16px;
        border-radius: 5px;
        cursor: pointer;
        display: none;
    }
    #backToTop:hover {
        background: #555;
    }
`;
document.head.appendChild(style);

// Show button when scrolling down
window.addEventListener('scroll', () => {
    if (window.scrollY > 300) {
        backToTopButton.style.display = 'block';
    } else {
        backToTopButton.style.display = 'none';
    }
});

// Scroll to top when clicked
backToTopButton.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
});